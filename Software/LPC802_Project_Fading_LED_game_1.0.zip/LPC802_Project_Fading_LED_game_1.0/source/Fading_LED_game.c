/**
 * @file    LPC802_Project_LED_GAME.c
 * @brief   Application entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "LPC802.h"
#include "fsl_debug_console.h"

#define PIN_LEDS_BP1			BOARD_INITPINS_LED_BP1_PIN
#define PIN_LEDS_BP2			BOARD_INITPINS_LED_BP2_PIN
#define PORT_LEDS_BP1			BOARD_INITPINS_LED_BP1_PORT
#define PORT_LEDS_BP2			BOARD_INITPINS_LED_BP2_PORT
#define MINUS_BUTTON_PORT 		BOARD_INITPINS_MINUS_BUTTON_PORT
#define MINUS_BUTTON_PIN		BOARD_INITPINS_MINUS_BUTTON_PIN
#define PLUS_BUTTON_PORT 		BOARD_INITPINS_PLUS_BUTTON_PORT
#define PLUS_BUTTON_PIN 		BOARD_INITPINS_PLUS_BUTTON_PIN

volatile uint32_t g_systickCounter;

#define MIN_VAL_WIN 1
uint8_t MAX_VAL_WIN = (100-MIN_VAL_WIN);

uint8_t DUTY_CYCLE;
uint32_t DELAY = 3000;    //10.000 = 1 sec 300 = 30ms

uint32_t WIN_OFF_WAIT = 200000;
#define WIN_BLINKING_CYCLES 5000
uint32_t WIN_BLINKING;
uint8_t WIN_DELAY = 70;

bool INCREASING = true;
bool DECREASING = false;

bool PLAYER_1_WIN = false;
bool PLAYER_2_WIN = false;

bool PLAYER_1_LOSE = false;
bool PLAYER_2_LOSE = false;

#define LOST_CUNTDOWN 50000	//10.000 = 1 sec 50000 = 500ms
uint16_t PLAYER1_WAIT_CUNTDOWN;
uint16_t PLAYER2_WAIT_CUNTDOWN;



void SysTick_Handler(void)
{
    if (g_systickCounter != 0U)
    {
        g_systickCounter--;
    }
}

void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;
    while (g_systickCounter != 0U)
    {
    }
}

int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    if (SysTick_Config(SystemCoreClock / 100000U))
    {
        while (1)
        {
        }
    }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    												//ACTUAL_CODE_STARS_HERE//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



    while(1) {
    	CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_1, 0);
    	CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_2, 0);
    	GPIO_PinWrite(GPIO, PORT_LEDS_BP1, PIN_LEDS_BP1, 0);
    	GPIO_PinWrite(GPIO, PORT_LEDS_BP2, PIN_LEDS_BP2, 0);
    	SysTick_DelayTicks(WIN_OFF_WAIT);

//Se Player 1 vince, i led di P1 blinkano per la vittoria e il duty cycle viene dimezzato
    	if (PLAYER_1_WIN == true) {
    		PLAYER_1_WIN = false;
    		DELAY = (DELAY/2);

    		for (WIN_BLINKING = WIN_BLINKING_CYCLES; WIN_BLINKING > 0; --WIN_BLINKING) {
				if (DUTY_CYCLE == 0) {
					INCREASING = true;
					DECREASING = false;
				}
				if (DUTY_CYCLE == 100) {
					INCREASING = false;
					DECREASING = true;
				}

				if ((INCREASING == true)&&(DECREASING == false)) {
					++DUTY_CYCLE;
				}

				if ((DECREASING == true)&&(INCREASING == false)) {
					--DUTY_CYCLE;
				}
				CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_1, DUTY_CYCLE);
				GPIO_PinWrite(GPIO, PORT_LEDS_BP1, PIN_LEDS_BP1, 1);
				SysTick_DelayTicks(WIN_DELAY);
    		}
    		CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_1, 0);
    		GPIO_PinWrite(GPIO, PORT_LEDS_BP1, PIN_LEDS_BP1, 0);
    		SysTick_DelayTicks(WIN_OFF_WAIT);
    	}

//Se Player 2 vince, i led di P2 blinkano per la vittoria e il duty cycle viene dimezzato
    		if (PLAYER_2_WIN == true) {
    		    		PLAYER_2_WIN = false;
    		    		DELAY = (DELAY/2);

    		    		for (WIN_BLINKING = WIN_BLINKING_CYCLES; WIN_BLINKING > 0; --WIN_BLINKING) {
    						if (DUTY_CYCLE == 0) {
    							INCREASING = true;
    							DECREASING = false;
    						}
    						if (DUTY_CYCLE == 100) {
    							INCREASING = false;
    							DECREASING = true;
    						}

    						if ((INCREASING == true)&&(DECREASING == false)) {
    							++DUTY_CYCLE;
    						}

    						if ((DECREASING == true)&&(INCREASING == false)) {
    							--DUTY_CYCLE;
    						}
    						CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_2, DUTY_CYCLE);
    						GPIO_PinWrite(GPIO, PORT_LEDS_BP2, PIN_LEDS_BP2, 1);
    						SysTick_DelayTicks(WIN_DELAY);
    		    		}
    		    		CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_2, 0);
    		    		GPIO_PinWrite(GPIO, PORT_LEDS_BP2, PIN_LEDS_BP2, 0);
    		    		SysTick_DelayTicks(WIN_OFF_WAIT);
    		}

//Inserito il DUTY_CYCLE che parte a 50. Senza, il duty parte a 0 e
//si può rimanere attaccati al pulsante dall'accensione per vincere sempre
    		DUTY_CYCLE = 50;

//Questo ciclo gestisce le vittorie, le perdite e il fading led
    	 while((PLAYER_1_WIN == false)&&(PLAYER_2_WIN == false)) {

    	    	if((GPIO_PinRead(GPIO, PLUS_BUTTON_PORT, PLUS_BUTTON_PIN) == 1) &&
    	    			((DUTY_CYCLE<=MIN_VAL_WIN) || (DUTY_CYCLE>=MAX_VAL_WIN))&&
    					(PLAYER_1_LOSE == false))
    	    	{
    	    		PLAYER_1_WIN = true;												//Vincita player 1
    	    	}

    	    	if((GPIO_PinRead(GPIO, PLUS_BUTTON_PORT, PLUS_BUTTON_PIN) == 1)&&
    	    			(PLAYER_1_WIN == false))
    	    	{
    	    		PLAYER_1_LOSE = true;												//Perde player 1
    	    		PLAYER1_WAIT_CUNTDOWN = (LOST_CUNTDOWN/DELAY);						//resetta il countdown della perdita ogni volta che perdi
    	    	}

    	    	if((GPIO_PinRead(GPIO, MINUS_BUTTON_PORT, MINUS_BUTTON_PIN) == 1)&&
    	    			((DUTY_CYCLE<=MIN_VAL_WIN)||(DUTY_CYCLE>=MAX_VAL_WIN))&&
    					(PLAYER_2_LOSE == false))
    	    	{
    	    		PLAYER_2_WIN = true;												//Vincita player 2
    	    	}

    	    	if((GPIO_PinRead(GPIO, MINUS_BUTTON_PORT, MINUS_BUTTON_PIN) == 1)&&
    	    	    	(PLAYER_2_WIN == false))
    	    	{
    				PLAYER_2_LOSE = true;												//Perde player 2
    				PLAYER2_WAIT_CUNTDOWN = (LOST_CUNTDOWN/DELAY);						//Resetta il countdown della perdita ogni volta che perdi
    			}

//Ogni ciclo in cui il giocatore non perde, il cuntdown viene ridotto di uno.
//Questo ciclo while, ha la durata di DELAY.
//Una perdita risulta in un tempo di pausa stabilito da lost_cuntdown.
//Quindi ho fatto LOST_CUNTDOWN/DELAY per trovare quanti cicli servono per
//far passare il tempo di cuntdown.
    	    	if (PLAYER_1_LOSE == true)
    	    	{
    	    		--PLAYER1_WAIT_CUNTDOWN;

    	    		if (PLAYER1_WAIT_CUNTDOWN == 0)
    	    		{
    	    			PLAYER_1_LOSE = false;
    	    		}
    	    	}

    	    	if (PLAYER_2_LOSE == true)
    	    	{
    	    		--PLAYER2_WAIT_CUNTDOWN;

    	    		if (PLAYER2_WAIT_CUNTDOWN == 0)
    	    		{
    	    			PLAYER_2_LOSE = false;
    	    		}
    	    	}

//Blinking code starts here
    	    	if (DUTY_CYCLE == 0) {
    	    		INCREASING = true;
    	    		DECREASING = false;
    	    	}

    	    	if (DUTY_CYCLE == 100) {
    	    	    		INCREASING = false;
    	    	    		DECREASING = true;
    	    	    	}

    	    	if ((INCREASING == true)&&(DECREASING == false)) {
    	    		++DUTY_CYCLE;
    	    	}

    	    	if ((DECREASING == true)&&(INCREASING == false)) {
    	    	    		--DUTY_CYCLE;
    	    	    	}

//Se P1 non perde, aggiorna il duty cycle dei LED P1
    	    	if (PLAYER_1_LOSE == false){
    	    		CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_1, DUTY_CYCLE);
    	    		GPIO_PinWrite(GPIO, PORT_LEDS_BP1, PIN_LEDS_BP1, 1);
    	    	}
//Se P1 perde, LED P1 si spegne per un tot
    	    	else if (PLAYER_1_LOSE == true){
    	    		CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_1, 0);
    	    		GPIO_PinWrite(GPIO, PORT_LEDS_BP1, PIN_LEDS_BP1, 0);
    	    	}
//Se P1 non perde, aggiorna il duty cycle dei LED P2
    	    	if (PLAYER_2_LOSE == false){
    	    		CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_2, DUTY_CYCLE);
    	    		GPIO_PinWrite(GPIO, PORT_LEDS_BP2, PIN_LEDS_BP2, 1);
    	    	}
//Se P2 perde, LED P2 si spegne per un tot
    	    	else if (PLAYER_2_LOSE == true){
        	    	CTIMER_UpdatePwmDutycycle(CTIMER0, kCTIMER_Match_0, kCTIMER_Match_2, 0);
        	    	GPIO_PinWrite(GPIO, PORT_LEDS_BP2, PIN_LEDS_BP2, 0);
        	    	}

    	    	SysTick_DelayTicks(DELAY);
//Blinking code ends here
    	    	}
    }
}
